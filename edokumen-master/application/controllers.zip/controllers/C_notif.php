<?php

class C_notif extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->table = 't_notif';
    }

    function getNotif()
    {
        $where = array(
            'opened' => '0', 
        );
        $data = $this->db->get_where($this->table, $where);
        $result = array(
            'count' => $data->num_rows(), 
            'data' => $data->result()
        );
        echo json_encode($result);
    }
}


?>