<?php
defined('BASEPATH') or exit('No direct script access allowed');

class C_upk extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        //cek login
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        }
        if ($this->session->userdata('level') != 1) {
            redirect(base_url());
        }
        $this->load->model('admin/M_upk', 'upk');
        $this->load->model('admin/M_config', 'config_');
    }

    public function list()
    {
        $data = array(
            'title' => 'DATA UPK',
            'menu' => 'upk',
            'script' => 'upk',
            'konten' => 'admin/upk/list'
        );

        $this->load->view('admin/templates/templates', $data, FALSE);
    }

    function data()
    {
        error_reporting(0);
        $list = $this->upk->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $field) {
            $idNa = $this->req->acak($field->id);
            // $idNa = $field->id;
            $button = "
                <button class='btn btn-danger btn-sm' id='delete' data-id='$idNa'><i class='fas fa-trash-alt'></i></button>
                <button class='btn btn-warning btn-sm' id='edit' data-id='$idNa'><i class='fas fa-pencil-alt'></i></button>
            ";
            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->kode_upk;
            $row[] = $field->upk;
            $row[] = $field->nama_user;
            $row[] = $field->keterangan;
            $row[] = $button;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->upk->count_all(),
            "recordsFiltered" => $this->upk->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function get($id)
    {
        $data = $this->upk->get($id);
        foreach ($data as $key => $value) {
            if (strtolower($key) == 'id') {
                $data->$key = $this->req->acak($value);
            }
        }
        echo json_encode($data);
    }

    function getPegawai()
    {
        echo json_encode($this->upk->data_pegawai());
    }

    function insert()
    {
        $upk = $this->req->input('kode_upk');
        $configData = [
            "$upk{}logo" => "",
            "$upk{}nama" => $this->req->input('upk'),
            "$upk{}alamat" => "",
            "$upk{}no_telp_1" => "",
            "$upk{}no_telp_2" => "",
            "$upk{}email" => "",
        ];

        $data = $this->req->all();

        foreach ($configData as $key => $value) {
            $dataNa[] = [
                'config' => $key,
                'value' => $value
            ];
        }

        if ($this->upk->insert($data) == true && $this->config_->insert_batch($dataNa)) {
            $msg = array(
                'status' => 'ok',
                'msg' => 'Berhasil menambahkan data !'
            );
        } else {
            $msg = array(
                'status' => 'fail',
                'msg' => 'Gagal menambahkan data !'
            );
        }
        echo json_encode($msg);
    }

    function update()
    {
        $id = $this->input->post('id');
        $data = $this->req->all(['id' => false]);
        if ($this->upk->update($data, $this->req->id($id)) == true) {
            $msg = array(
                'status' => 'ok',
                'msg' => 'Berhasil mengubah data !'
            );
        } else {
            $msg = array(
                'status' => 'fail',
                'msg' => 'Gagal mengubah data !'
            );
        }
        echo json_encode($msg);
    }

    function delete($id)
    {
        $idUpk = $this->req->getIdUpk($id);
        if ($this->req->cekRelasiUpk($idUpk->id)) {
            if ($this->upk->delete($this->req->id($id)) == true && $this->config_->deleteConfig($idUpk->kode_upk) == true) {
                $msg = array(
                    'status' => 'ok',
                    'msg' => 'Berhasil menghapus data !'
                );
            } else {
                $msg = array(
                    'status' => 'fail',
                    'msg' => 'Gagal menghapus data !'
                );
            }
            echo json_encode($msg);
        } else {
            $msg = array(
                'status' => 'fail',
                'msg' => 'Data yang saling terhubung tidak dapat dihapus!'
            );
            echo json_encode($msg);
        }
    }
}
