<?php

defined('BASEPATH') or exit('No direct script access allowed');

class C_verifikasi extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        }
        $this->load->model('admin/M_verifikasi', 'verifikasi');
    }


    public function list()
    {

        $jabatan = $this->verifikasi->data_jabatan();
        $user = $this->verifikasi->data_user();
        $data = array(
            'title'   => 'Verifikasi Surat Masuk',
            'jabatan' => $jabatan,
            'user'    => $user,
            'menu'    => 'verifikasi-masuk',
            'script'  => 'verifikasi',
            'konten'  => 'admin/surat/verifikasi',
        );

        $this->load->view('admin/templates/templates', $data, FALSE);
    }


  function data($tipe = null)
    {
        error_reporting(0);
        if ($tipe == 'user') {
            $this->verifikasi->tipe = $this->session->userdata('id_user');
        }
        if ($_POST['tipeKirim'] != null) {
            $this->verifikasi->tipeKirim = $_POST['tipeKirim'];
        }
        // echo $_POST['tipeKirim'];
        $list = $this->verifikasi->get_datatables();
        // $this->req->query();
        $data = array();
        $no = $_POST['start'];
        $config_ = $this->db->get_where('t_config', ['config' => 'keyua_yayasan'])->row();
        $ketuaYayasan = $config->value;
        foreach ($list as $field) {
            $idNa = $this->req->acak($field->id);
            $accField = explode(',', $field->persetujuan);
            // $idNa = $field->id;
            $confirm = $field->acc;
            if (strpos($confirm, $this->session->id_user) > -1) {
                $btnConfirm = "";
            } else {
                if  ($this->session->id_user  == $ketuaYayasan){
                    if ($accField[0] == $ketuaYayasan) {
                        if (strpos($confirm, $accField[1]) > -1) {
                            $btnConfirm = "<button class='btn btn-success btn-sm' id='confirm' data-id='$idNa'><i  class='fas fa-check-circle'></i></button>";
                        } else {
                            $btnConfirm = "";
                        }
                    }   
                } else {
                    $btnConfirm = "<button class='btn btn-success btn-sm' id='confirm' data-id='$idNa'><i class='fas fa-check-circle'></i></button>";
                }
            }
            $button = "
                    <button class='btn btn-primary btn-sm' id='lihat' data-id='$idNa'><i class='fas fa-eye'></i></button>
                    $btnConfirm
                    ";


            if ($field->status_pengiriman == '1') {
                $statusNa= "Belum di verifikasi / Masih di Proses";
            }
            if ($field->status_pengiriman == '2') {
                $statusNa= "Dikembalikan";
            }
            if ($field->status_pengiriman == '0') {
                $statusNa= "Selesai";
            }
            if ($field->status_pengiriman == '4') {
                $statusNa = "Tidak Disetujui";
            }


            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $field->no_surat;
            $row[] = $field->tanggal_dibuat;
            $row[] = $field->upk;
            $row[] = $field->jenis;
            $row[] = $field->sifat;
            $row[] = $field->perihal;
            $row[] = $statusNa;
            $row[] = $button;
            $data[] = $row;
        }

        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $this->verifikasi->count_all(),
            "recordsFiltered" => $this->verifikasi->count_filtered(),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function get($id)
    {
        // $this->db->select('surat.id, surat.tanggal_dibuat, surat.no_surat, up.upk as asal_surat');
        // $this->db->from('t_suratkeluar as surat');
        // $this->db->join('t_upk as up', 'up.id = surat.asal_surat', 'left');
        $data = $this->verifikasi->get($id);
        // foreach ($data as $key => $value) {
        //     if (strtolower($key) == 'id') {
        //         $data->$key = $this->req->acak($value);
        //     }
        // }
        echo json_encode($data);
    }

   
    
    public function addVerif()
    {
        $id = $this->req->input('id_surat');
        $surat = $this->db->get_where('t_suratkeluar', ['id' => $id])->row();
        $accNa = $surat->acc;
        if ($accNa != '') {
            $accNa .= $this->session->id_user . ",";
        } else {
            $accNa = $this->session->id_user . ",";
        }
        $data = [
            'acc' => $accNa,
            'status_pengiriman' => '0',
        ];
        if ($this->verifikasi->update($data, ['id' => $id])) {
            echo json_encode([
                'status' => 'ok',
                'msg' => 'Berhasil mem-verifikasi Data !'
            ]);
        } else {
            echo json_encode([
                'status' => 'fail',
                'msg' => 'Gagal mem-verifikasi Data !'
            ]);
        }
    }


    public function insert_revisi()
    {
        $id = $this->input->post('id_verifikasi');

         if ($this->verifikasi->update([
            'status_verifikasimasuk' => '0',
            'disposisi' => '2'
        ], $this->req->id($id)) == true) {
                // echo "verifikasi masuk asup";
            }

        $data = $this->req->all();
        if ($this->verifikasi->insert_disposisi($data) == true) {
            $msg = array(
                'status' => 'ok',
                'msg' => 'Berhasil Disposisi !'
            );
        } else {
            $msg = array(
                'status' => 'fail',
                'msg' => 'Gagal Disposisi !'
            );
        }            
        // echo $this->db->last_query();
        echo json_encode($msg);
    }
}
