<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class C_home extends CI_Controller {

    function __construct()
    {
        parent::__construct();
        //cek login
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        }
    }

    public function home()
    {
        $data = array(
            'title' => 'Dashboard - E Office' ,
            'konten' => 'admin/home/dashboard',
            'menu' => 'home',
            'script' => '',    
        );
        
        $this->load->view('admin/templates/templates', $data, FALSE);
        
    }

}

/* End of file C_home.php */
